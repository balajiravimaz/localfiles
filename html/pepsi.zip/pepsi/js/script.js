function slide(img) {
  document.querySelector(".pepsi").src = img;
}
function changebg(col) {
  const sec = document.querySelector(".sci");
  sec.style.background = col;
}
